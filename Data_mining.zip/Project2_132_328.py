import pandas as pd
import math
import numpy as np
import seaborn as sns
from tkinter import *
from tkinter import ttk
import tkinter as tk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn import svm
from sklearn import metrics

class SVM:
    def __init__(self, df, chosenColumn, test_size=0.2, random_state_train=0, kernel='linear'):
        self.gdv = Tk()
        self.gdv.geometry("5000x103")
        self.gdv.title('SVM classification of ' + chosenColumn)

        self.df = df
        self.chosenColumn = chosenColumn

        self.test_size = float(test_size)
        self.random_state_train = int(random_state_train)
        self.train_X_df, self.val_X_df, self.train_y_sr, self.val_y_sr = self.split()
        Label(self.gdv, text=str(self.clf(str(kernel)))).pack()

    def split(self):
        X_df = self.df.drop(columns=[self.chosenColumn], axis=1)
        y_sr = self.df[self.chosenColumn]

        return train_test_split(X_df, y_sr, test_size=self.test_size,
                                stratify=y_sr, random_state=self.random_state_train)

    def clf(self, kernel):
        clf = svm.SVC(kernel=kernel)
        clf.fit(self.train_X_df, self.train_y_sr)

        predict = clf.predict(self.val_X_df)
        p = "[ "

        for i in predict:
            if i == 0:
                p = p + 'B '
            else:
                p = p + 'M '

        return "Predict: " + p + ' ]\nScore: ' + str(clf.score(self.val_X_df, self.val_y_sr)) + '\nAccuracy: ' + str(metrics.accuracy_score(self.val_y_sr, predict))

class MLP:
    def __init__(self, df, chosenColumn, test_size=0.2, random_state_train=0, hidden_layer_sizes=50, activation='relu', solver='lbfgs', random_state=0, max_iter=10000):
        self.gdv = Tk()
        self.gdv.geometry("5000x103")
        self.gdv.title('Classification of ' + chosenColumn)

        self.df = df
        self.chosenColumn = chosenColumn

        self.test_size = float(test_size)
        self.random_state_train = int(random_state_train)
        self.train_X_df, self.val_X_df, self.train_y_sr, self.val_y_sr = self.split()
        Label(self.gdv, text=str(self.mlp(int(hidden_layer_sizes), str(activation),
                                 str(solver), int(random_state), int(max_iter)))).pack()

    def split(self):
        X_df = self.df.drop(columns=[self.chosenColumn], axis=1)
        y_sr = self.df[self.chosenColumn]

        return train_test_split(X_df, y_sr, test_size=self.test_size,
                                stratify=y_sr, random_state=self.random_state_train)

    def mlp(self, hidden_layer_sizes, activation, solver, random_state, max_iter):
        mlp = MLPClassifier(hidden_layer_sizes=hidden_layer_sizes,
                            activation=activation, solver=solver,
                            random_state=random_state, max_iter=max_iter)
        mlp.fit(self.train_X_df, self.train_y_sr)

        predict = mlp.predict(self.val_X_df)
        p = "[ "

        for i in predict:
            if i == 0:
                p = p + 'B '
            else:
                p = p + 'M '

        return "Predict: " + p + ' ]\nScore: ' + str(mlp.score(self.val_X_df, self.val_y_sr)) + '\nAccuracy: ' + str(metrics.accuracy_score(self.val_y_sr, predict))

class drawGui:
    def __init__(self, df, chosenColumn, type=[]):
        self.gdv = Tk()
        self.gdv.geometry("5000x5000")
        self.gdv.title('Visual of ' + chosenColumn)

        self.df = df
        self.chosenColumn = chosenColumn
        self.tabDraw = ttk.Notebook(self.gdv)

        for i in type:
            if i == 0:
                if (self.df[self.chosenColumn].dtypes == object):
                    l = Label(self.gdv, text="This column can't be statistic")
                    l.pack()
                else:
                    l = Label(self.gdv,
                              text=f"Basic statistic of {self.chosenColumn}:\n---------------------\nMax: {self.df[self.chosenColumn].max()}\n"
                                   f"Min: {self.df[self.chosenColumn].min()}\nvariance: "
                                   f"{round(self.variance(), 2)}\nMean: {round(self.df[self.chosenColumn].mean(), 2)}"
                                   f"\nLow median: {self.median_Low()}\nMedian: {self.df[self.chosenColumn].median()}"
                                   f"\nHigh median: {self.median_High()}\nStd: {round(self.stddev(), 2)}"
                                   f"\nMad: {round(self.mydev(), 2)}\n---------------------")

                    l.pack()

                continue

            if i == 1:
                self.tabBar = tk.Frame(self.tabDraw, width=2500, height=2500)
                self.tabDraw.add(self.tabBar, text='Bar chart')
                self.drawBarChart()

                continue

            if i == 2:
                self.tabLine = tk.Frame(self.tabDraw, width=2500, height=2500)
                self.tabDraw.add(self.tabLine, text='Line graph')
                self.drawLineGraph()

                continue

            if i == 3:
                self.tabBox = tk.Frame(self.tabDraw, width=2500, height=2500)
                self.tabDraw.add(self.tabBox, text='Boxplot')
                self.drawBoxPlot()

                continue

            if i == 4:
                self.tabWf = tk.Frame(self.tabDraw, width=2500, height=2500)
                self.tabDraw.add(self.tabWf, text='Water fall chart')
                self.drawWaterFall()

                continue

            if i == 5:
                self.tabHist = tk.Frame(self.tabDraw, width=2500, height=2500)
                self.tabDraw.add(self.tabHist, text='Histogram')
                self.drawHist()

                continue

        self.tabDraw.pack(expand=1, fill="both")

    def createFig(self, tab):
        figure = plt.Figure(figsize=(10, 10), dpi=103)
        ax = figure.add_subplot(111)
        chart_type = FigureCanvasTkAgg(figure, tab)
        chart_type.get_tk_widget().pack()

        return ax

    def median_Low(self):
        data = sorted(self.df[self.chosenColumn])
        n = len(data)

        if n % 2 == 1:
            return data[n // 2]
        else:
            return data[n // 2 - 1]

    def median_High(self):
        data = sorted(self.df[self.chosenColumn])
        n = len(data)

        return data[n // 2]


    def mydev(self):
        mu = self.df[self.chosenColumn].mean()

        return sum([abs(point - mu) for point in self.df[self.chosenColumn]]) / len(self.df[self.chosenColumn])


    def variance(self):
        mu = self.df[self.chosenColumn].mean()

        return sum([(point - mu) ** 2 for point in self.df[self.chosenColumn]]) / len(self.df[self.chosenColumn])

    def stddev(self):
        return math.sqrt(self.variance())

    def drawBarChart(self):
        ax = self.createFig(self.tabBar)
        sns.barplot(x=self.chosenColumn, y='counts', data=pd.DataFrame(self.df[self.chosenColumn].value_counts().rename_axis(self.chosenColumn).reset_index(name='counts')), ax=ax)

        ax.set_title('Bar chart of ' + self.chosenColumn)
        plt.show()

    def drawLineGraph(self):
        ax = self.createFig(self.tabLine)

        sns.lineplot(x=self.chosenColumn, y='counts', data=pd.DataFrame(self.df[self.chosenColumn].value_counts().rename_axis(self.chosenColumn).reset_index(name='counts')), ax=ax)

        ax.set_title('Line graph of ' + self.chosenColumn)
        plt.show()

    def drawBoxPlot(self):
        ax = self.createFig(self.tabBox)
        ax.boxplot(self.df[self.chosenColumn])
        ax.set_title('Boxplot of ' + self.chosenColumn)
        plt.show()

    def drawWaterFall(self):
        ax = self.createFig(self.tabWf)
        df = pd.DataFrame(self.df[self.chosenColumn].value_counts())
        blank = df[self.chosenColumn].cumsum().shift(1).fillna(0)
        total = df.sum()[self.chosenColumn]
        df.loc["net"] = total
        blank.loc["net"] = total

        step = blank.reset_index(drop=True).repeat(3).shift(-1)
        step[1::3] = np.nan
        blank.loc["net"] = 0
        wf = df.plot(kind='bar', stacked=True, bottom=blank, legend=None, figsize=(10, 5), ax=ax)
        wf.plot(step.index, step.values, 'k')
        ax.set_title('Water fall chart of ' + self.chosenColumn)
        plt.show()

    def drawHist(self):
        ax = self.createFig(self.tabHist)

        mean = self.df[self.chosenColumn].mean()
        median = self.df[self.chosenColumn].median()
        mode = self.df[self.chosenColumn].mode().values[0]
        mad = self.mydev()
        #std = self.stddev

        sns.histplot(data=self.df, x=self.chosenColumn, ax=ax, kde=True)
        ax.axvline(mean, color='r', linestyle='--', label="Mean")
        ax.axvline(median, color='g', linestyle='dashed', label="Median")
        ax.axvline(mode, color='b', linestyle='solid', label="Mode")
        ax.axvline(mad, color='w', linestyle='dashdot', label="MAD")
        #ax.axvline(std, color='y', linestyle='dotted', label="STD")

        ax.legend()
        ax.set_title('Histogram of ' + self.chosenColumn)
        plt.show()

class Gui:
    def initCombobox(self, tab, list_c=[]):
        combo = ttk.Combobox(tab, values=list_c)  # , state="readonly")
        combo.set("Option")
        combo.place(x=23, y=28)

        return combo

    def initListbox(self, tab, list_c=[]):
        box = tk.Listbox(tab, selectmode=tk.MULTIPLE, height=3)

        for val in list_c:
            box.insert(tk.END, val)

        box.config(height=box.size())

        return box

    def visual(self):
        self.chosenColumn = self.column.get()

        if (self.chosenColumn not in self.listColumn):
            l = Label(self.tabVisual, text="No column name found")
            l.pack()

            return

        self.chosenColumn = self.column.get()
        selected = self.columnG.curselection()

        #for idx in selected:
        #    self.chosenColumnG.append(self.columnG.get(idx))

        drawGui(self.df, self.chosenColumn, list(selected))
        self.chosenColumnG.clear()

    def runMLP(self):
        #self.chosenColumnMLP = self.columnMLP.get()
        dfMS = self.dfMS.get()
        dfMRS = self.dfMRS.get()
        mlpHS = self.mlpHS.get()
        mlpA = self.mlpA.get()
        mlpS = self.mlpS.get()
        mlpRS = self.mlpRS.get()
        mlpMI = self.mlpMI.get()

        if dfMS == '':
            dfMS = 0.2
        if dfMRS == '':
            dfMRS = 0
        if mlpHS == '':
            mlpHS = 50
        if mlpA == '':
            mlpA = 'relu'
        if mlpS == '':
            mlpS = 'lbfgs'
        if mlpRS == '':
            mlpRS = 0
        if mlpMI == '':
            mlpMI = 10000

        MLP(self.df, 'diagnosis', dfMS,
            dfMRS, mlpHS, mlpA,
            mlpS, mlpRS, mlpMI)

    def runSVM(self):
        dfSS = self.dfSS.get()
        dfSRS = self.dfSRS.get()
        svmK = self.svmK.get()

        if dfSS == '':
            dfSS = 0.2
        if dfSRS == '':
            dfSRS = 0
        if svmK == '':
            svmK = 'linear'

        SVM(self.df, 'diagnosis', dfSS, dfSRS, svmK)

    def run(self):
        self.gdv.mainloop()

    def __init__(self, df):
        self.gdv = Tk()
        self.gdv.geometry("500x500")
        self.gdv.title("Dataset:" + df.name)

        # create window
        self.tabMining = ttk.Notebook(self.gdv)
        self.tabVisual = tk.Frame(self.tabMining, width=103, height=103)
        self.tabMLP = tk.Frame(self.tabMining, width=500, height=500)
        self.tabSVM = tk.Frame(self.tabMining, width=500, height=500)
        self.tabMining.add(self.tabVisual, text='Tab graph')
        self.tabMining.add(self.tabMLP, text='MLP Classification')
        self.tabMining.add(self.tabSVM, text='SVM Classification')
        self.tabMining.pack(expand=1, fill="both")

        # init variables
        self.df = df
        self.listColumn = list(self.df.keys())
        self.listG = ['Describe', 'Bar chart', 'Line graph', 'Boxplot', 'Water fall chart', 'Histogram']
        self.chosenColumn = StringVar
        self.chosenColumnG = []
        #self.chosenColumnMLP = StringVar

        # init function button
        self.column = self.initCombobox(self.tabVisual, self.listColumn)
        self.columnG = self.initListbox(self.tabVisual, self.listG)
        self.buttonV = ttk.Button(self.tabVisual, text="Calculate", command=self.visual)

        #self.columnMLP = self.initCombobox(self.tabMLP, self.listColumn)
        self.dfMTSize = Label(self.tabMLP, text="Enter test train size")
        self.dfMS = Entry(self.tabMLP, width=10, borderwidth=3)
        self.dfMRanState = Label(self.tabMLP, text="Enter train random state")
        self.dfMRS = Entry(self.tabMLP, width=10, borderwidth=3)
        self.mlpHSize = Label(self.tabMLP, text="Enter hidden size")
        self.mlpHS = Entry(self.tabMLP, width=10, borderwidth=3)
        self.mlpActive = Label(self.tabMLP, text="Enter activation")
        self.mlpA = Entry(self.tabMLP, width=10, borderwidth=3)
        self.mlpSolver = Label(self.tabMLP, text="Enter solver")
        self.mlpS = Entry(self.tabMLP, width=10, borderwidth=3)
        self.mlpRanState = Label(self.tabMLP, text="Enter random state")
        self.mlpRS = Entry(self.tabMLP, width=10, borderwidth=3)
        self.mlpMaxI = Label(self.tabMLP, text="Enter max iters")
        self.mlpMI = Entry(self.tabMLP, width=10, borderwidth=3)
        self.buttonMLP = Button(self.tabMLP, text="Confirm", command=self.runMLP)

        self.dfSTSize = Label(self.tabSVM, text="Enter test train size")
        self.dfSS = Entry(self.tabSVM, width=10, borderwidth=3)
        self.dfSRanState = Label(self.tabSVM, text="Enter train random state")
        self.dfSRS = Entry(self.tabSVM, width=10, borderwidth=3)
        self.svmKernel = Label(self.tabSVM, text="Enter kernel")
        self.svmK = Entry(self.tabSVM, width=10, borderwidth=3)
        self.buttonSVM = Button(self.tabSVM, text="Confirm", command=self.runSVM)

        self.column.pack()
        self.columnG.pack()
        self.buttonV.pack()

        self.dfMTSize.pack()
        self.dfMS.pack()
        self.dfMRanState.pack()
        self.dfMRS.pack()
        #self.columnMLP.pack()
        self.mlpHSize.pack()
        self.mlpHS.pack()
        self.mlpActive.pack()
        self.mlpA.pack()
        self.mlpSolver.pack()
        self.mlpS.pack()
        self.mlpRanState.pack()
        self.mlpRS.pack()
        self.mlpMaxI.pack()
        self.mlpMI.pack()
        self.buttonMLP.pack()

        self.dfSTSize.pack()
        self.dfSS.pack()
        self.dfSRanState.pack()
        self.dfSRS.pack()
        self.svmKernel.pack()
        self.svmK.pack()
        self.buttonSVM.pack()

def preprocessing(df):
    df.drop(columns=['id','Unnamed: 32'],axis=1,inplace=True)
    df['diagnosis'] = [1 if x == 'M' else 0 for x in df['diagnosis']]
    df.round(2)

def run_dataset(dataset):
    df = pd.read_csv(dataset)
    df.name = dataset
    preprocessing(df)
    gui = Gui(df)
    gui.run()

root = Tk()
root.title("Project 2")
root.geometry("230x50")
label = Label(root, text="Enter path dataset: ")
label.grid(row=0, column=0)
e = Entry(root, width=10, borderwidth=3)
e.grid(row=0, column=1, columnspan=3)
button = Button(root,text="Loading", command=lambda: run_dataset(e.get()))
button.grid(row=1, column=1)
root.mainloop()
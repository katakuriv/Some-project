﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace DHMT_Lab_1
{
    public partial class Form1 : Form
    {
        private Shape MyShape = new Shape();
        private bool State = false;
        private bool IsMouseDown = false;
        private int red = 255;
        private int green = 0;
        private int blue = 0;
        private int thick = 1;
        private int m_StartX;
        private int m_StartY;
        private int m_CurX;
        private int m_CurY;
        private string KindCase = "";
        private string TypeCase = "";
        Point Point1 = new Point();
        Point Point2 = new Point();
        Point StartDownLocation = new Point();

        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            KindCase = comboBox1.Text;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            TypeCase = comboBox2.Text;
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            IsMouseDown = true;

            m_StartX = e.X;
            m_StartY = e.Y;
            m_CurX = e.X;
            m_CurY = e.Y;
            StartDownLocation = e.Location;
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            Pen dashed_pen = new Pen(Color.Green, 1);

            dashed_pen.DashStyle = DashStyle.Dash;

            if (IsMouseDown == false)
            {
                return;
            }

            m_CurX = e.X;
            m_CurY = e.Y;

            switch (KindCase)
            {
                case "Draw":
                    {
                        State = false;
                        break;
                    }
                case "Move":
                    {
                        if (State == true)
                        {
                            Point1.X = e.X + MyShape.X1 - StartDownLocation.X;
                            Point1.Y = e.Y + MyShape.Y1 - StartDownLocation.Y;
                            Point2.X = e.X + MyShape.X2 - StartDownLocation.X;
                            Point2.Y = e.Y + MyShape.Y2 - StartDownLocation.Y;
                        }
                        
                        break;
                    }
            }

            pictureBox1.Invalidate();
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            IsMouseDown = false;

            if (e.Button == MouseButtons.Left)
            {
                switch (KindCase)
                {
                    case "Draw":
                        {
                            MyShape = new Shape(m_StartX, m_StartY, m_CurX, m_CurY);
                            State = true;
                            break;
                        }
                    case "Move":
                        {
                            MyShape = new Shape(Point1.X, Point1.Y, Point2.X, Point2.Y);

                            break;
                        }
                }

                pictureBox1.Invalidate();
            }
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            if (State == true)
            {
                if (TypeCase == "Line segment")
                {
                    e.Graphics.DrawLine(new Pen(Color.FromArgb(255, red, green, blue), 3), MyShape.X1, MyShape.Y1, MyShape.X2, MyShape.Y2);
                }
                else if (TypeCase == "Circle")
                {
                    e.Graphics.DrawEllipse(new Pen(Color.FromArgb(255, red, green, blue), 3), MyShape.X1, MyShape.Y1, Convert.ToInt32(2 * Math.Sqrt(Math.Pow(MyShape.X2 - MyShape.X1, 2) + Math.Pow(MyShape.Y2 - MyShape.Y1, 2))), Convert.ToInt32(2 * Math.Sqrt(Math.Pow(MyShape.X2 - MyShape.X1, 2) + Math.Pow(MyShape.Y2 - MyShape.Y1, 2))));
                }
                else if (TypeCase == "Rectangle")
                {
                    e.Graphics.DrawRectangle(new Pen(Color.FromArgb(255, red, green, blue), 3), MyShape.X1, MyShape.Y1, Convert.ToInt32(Math.Sqrt(Math.Pow(MyShape.X2 - MyShape.X1, 2) + Math.Pow(MyShape.Y2 - MyShape.Y1, 2))), Convert.ToInt32((Math.Sqrt(Math.Pow(MyShape.X2 - MyShape.X1, 2) + Math.Pow(MyShape.Y2 - MyShape.Y1, 2)) / 2)));
                }
                else if (TypeCase == "Ellipse")
                {
                    e.Graphics.DrawEllipse(new Pen(Color.FromArgb(255, red, green, blue), 3), MyShape.X1, MyShape.Y1, Convert.ToInt32(2 * Math.Sqrt(Math.Pow(MyShape.X2 - MyShape.X1, 2) + Math.Pow(MyShape.Y2 - MyShape.Y1, 2))), Convert.ToInt32(Math.Sqrt(Math.Pow(MyShape.X2 - MyShape.X1, 2) + Math.Pow(MyShape.Y2 - MyShape.Y1, 2))));
                }
                else if (TypeCase == "Equilateral rectangle")
                {
                    e.Graphics.DrawRectangle(new Pen(Color.FromArgb(255, red, green, blue), 3), MyShape.X1, MyShape.Y1, Convert.ToInt32(Math.Sqrt(Math.Pow(MyShape.X2 - MyShape.X1, 2) + Math.Pow(MyShape.Y2 - MyShape.Y1, 2))), Convert.ToInt32(Math.Sqrt(Math.Pow(MyShape.X2 - MyShape.X1, 2) + Math.Pow(MyShape.Y2 - MyShape.Y1, 2))));
                }
                else if (TypeCase == "Equilateral pentagon")
                {
                    float r = Convert.ToInt32(Math.Sqrt(Math.Pow(MyShape.X2 - MyShape.X1, 2) + Math.Pow(MyShape.Y2 - MyShape.Y1, 2)));
                    Point point1 = new Point(MyShape.X1, MyShape.Y1 - (int)r);
                    Point point2 = new Point(MyShape.X1 - (int)(0.951f * r), MyShape.Y1 - (int)(0.309f * r));
                    Point point3 = new Point(MyShape.X1 - (int)(0.587f * r), MyShape.Y1 - (int)(0.809f * r));
                    Point point4 = new Point(MyShape.X1 - (int)(0.587f * r), MyShape.Y1 - (int)(0.809f * r));
                    Point point5 = new Point(MyShape.X1 - (int)(0.951f * r), MyShape.Y1 - (int)(0.309f * r));
                    Point[] curvePoints = { point1, point2, point3, point4, point5 };

                    e.Graphics.DrawPolygon(new Pen(Color.FromArgb(255, red, green, blue), 3), curvePoints);
                }
            }

            if (IsMouseDown == true)
            {
                switch (KindCase)
                {
                    case "Draw":
                        {
                            switch (TypeCase)
                            {
                                case "Line segment":
                                    e.Graphics.DrawLine(new Pen(Color.FromArgb(255, red, green, blue), thick), m_StartX, m_StartY, m_CurX, m_CurY);
                                    break;
                                case "Circle":
                                    e.Graphics.DrawEllipse(new Pen(Color.FromArgb(255, red, green, blue), thick), m_StartX, m_StartY, Convert.ToInt32(2 * Math.Sqrt(Math.Pow(m_CurX - m_StartX, 2) + Math.Pow(m_CurY - m_StartY, 2))), Convert.ToInt32(2 * Math.Sqrt(Math.Pow(m_CurX - m_StartX, 2) + Math.Pow(m_CurY - m_StartY, 2))));
                                    break;
                                case "Rectangle":
                                    e.Graphics.DrawRectangle(new Pen(Color.FromArgb(255, red, green, blue), thick), m_StartX, m_StartY, Convert.ToInt32(Math.Sqrt(Math.Pow(m_CurX - m_StartX, 2) + Math.Pow(m_CurY - m_StartY, 2))), Convert.ToInt32((Math.Sqrt(Math.Pow(m_CurX - m_StartX, 2) + Math.Pow(m_CurY - m_StartY, 2)) / 2)));
                                    break;
                                case "Ellipse":
                                    e.Graphics.DrawEllipse(new Pen(Color.FromArgb(255, red, green, blue), thick), m_StartX, m_StartY, Convert.ToInt32(2 * Math.Sqrt(Math.Pow(m_CurX - m_StartX, 2) + Math.Pow(m_CurY - m_StartY, 2))), Convert.ToInt32(Math.Sqrt(Math.Pow(m_CurX - m_StartX, 2) + Math.Pow(m_CurY - m_StartY, 2))));
                                    break;
                                case "Equilateral rectangle":
                                    e.Graphics.DrawRectangle(new Pen(Color.FromArgb(255, red, green, blue), thick), m_StartX, m_StartY, Convert.ToInt32(Math.Sqrt(Math.Pow(m_CurX - m_StartX, 2) + Math.Pow(m_CurY - m_StartY, 2))), Convert.ToInt32(Math.Sqrt(Math.Pow(m_CurX - m_StartX, 2) + Math.Pow(m_CurY - m_StartY, 2))));
                                    break;
                                case "Equilateral pentagon":
                                    float r = Convert.ToInt32(Math.Sqrt(Math.Pow(m_CurX - m_StartX, 2) + Math.Pow(m_CurY - m_StartY, 2)));
                                    Point point1 = new Point(m_StartX, MyShape.Y1 - (int)r);
                                    Point point2 = new Point(m_StartX - (int)(0.951f * r), m_StartY - (int)(0.309f * r));
                                    Point point3 = new Point(m_StartX - (int)(0.587f * r), m_StartY - (int)(0.809f * r));
                                    Point point4 = new Point(m_StartX - (int)(0.587f * r), m_StartY - (int)(0.809f * r));
                                    Point point5 = new Point(m_StartX - (int)(0.951f * r), m_StartY - (int)(0.309f * r));
                                    Point[] curvePoints = { point1, point2, point3, point4, point5 };

                                    e.Graphics.DrawPolygon(new Pen(Color.FromArgb(255, red, green, blue), thick), curvePoints);
                                    break;
                            }

                            break;
                        }                   
                    case "Move":
                        {
                            switch (TypeCase)
                            {
                                case "Line segment":
                                    e.Graphics.DrawLine(new Pen(Color.FromArgb(255, red, green, blue), thick), Point1.X, Point1.Y, Point2.X, Point2.Y);
                                    break;
                                case "Circle":
                                    e.Graphics.DrawEllipse(new Pen(Color.FromArgb(255, red, green, blue), thick), Point1.X, Point1.Y, Convert.ToInt32(2 * Math.Sqrt(Math.Pow(Point2.X - Point1.X, 2) + Math.Pow(Point2.Y - Point1.Y, 2))), Convert.ToInt32(2 * Math.Sqrt(Math.Pow(Point2.X - Point1.X, 2) + Math.Pow(Point2.Y - Point1.Y, 2))));
                                    break;
                                case "Rectangle":
                                    e.Graphics.DrawRectangle(new Pen(Color.FromArgb(255, red, green, blue), thick), Point1.X, Point1.Y, Convert.ToInt32(Math.Sqrt(Math.Pow(Point2.X - Point1.X, 2) + Math.Pow(Point2.Y - Point1.Y, 2))), Convert.ToInt32((Math.Sqrt(Math.Pow(Point2.X - Point1.X, 2) + Math.Pow(Point2.Y - Point1.Y, 2)) / 2)));
                                    break;
                                case "Ellipse":
                                    e.Graphics.DrawEllipse(new Pen(Color.FromArgb(255, red, green, blue), thick), Point1.X, Point1.Y, Convert.ToInt32(2 * Math.Sqrt(Math.Pow(Point2.X - Point1.X, 2) + Math.Pow(Point2.Y - Point1.Y, 2))), Convert.ToInt32(Math.Sqrt(Math.Pow(Point2.X - Point1.X, 2) + Math.Pow(Point2.Y - Point1.Y, 2))));
                                    break;
                                case "Equilateral rectangle":
                                    e.Graphics.DrawRectangle(new Pen(Color.FromArgb(255, red, green, blue), thick), Point1.X, Point1.Y, Convert.ToInt32(Math.Sqrt(Math.Pow(Point2.X - Point1.X, 2) + Math.Pow(Point2.Y - Point1.Y, 2))), Convert.ToInt32(Math.Sqrt(Math.Pow(Point2.X - Point1.X, 2) + Math.Pow(Point2.Y - Point1.Y, 2))));
                                    break;
                                case "Equilateral pentagon":
                                    float r = Convert.ToInt32(Math.Sqrt(Math.Pow(Point2.X - Point1.X, 2) + Math.Pow(Point2.Y - Point1.Y, 2)));
                                    Point point1 = new Point(Point1.X, Point1.Y - (int)r);
                                    Point point2 = new Point(Point1.X - (int)(0.951f * r), Point1.Y - (int)(0.309f * r));
                                    Point point3 = new Point(Point1.X - (int)(0.587f * r), Point1.Y - (int)(0.809f * r));
                                    Point point4 = new Point(Point1.X - (int)(0.587f * r), Point1.Y - (int)(0.809f * r));
                                    Point point5 = new Point(Point1.X - (int)(0.951f * r), Point1.Y - (int)(0.309f * r));
                                    Point[] curvePoints = { point1, point2, point3, point4, point5 };

                                    e.Graphics.DrawPolygon(new Pen(Color.FromArgb(255, red, green, blue), thick), curvePoints);
                                    break;
                            }

                            break;
                        }
                }
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.Handled == char.IsDigit(e.KeyChar))
            {
                red = int.Parse(textBox1.Text);

                if (red > 255)
                {
                    red = 255;
                }
                else if (red < 0)
                {
                    red = 0;
                }
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.Handled == char.IsDigit(e.KeyChar))
            {
                green = int.Parse(textBox1.Text);

                if (green > 255)
                {
                    green = 255;
                }
                else if (green < 0)
                {
                    green = 0;
                }
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.Handled == char.IsDigit(e.KeyChar))
            {
                blue = int.Parse(textBox1.Text);

                if (blue > 255)
                {
                    blue = 255;
                }
                else if (blue < 0)
                {
                    blue = 0;
                }
            }
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.Handled == char.IsDigit(e.KeyChar))
            {
                thick = int.Parse(textBox1.Text);

                if (thick > 103)
                {
                    thick = 103;
                }
                else if (thick < 0)
                {
                    thick = 0;
                }
            }
        }
    }
}
